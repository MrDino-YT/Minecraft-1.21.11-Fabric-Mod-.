package com.example.randomenchants;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Simple JSON config stored at config/random_enchants.json. */
public final class RandomEnchantsConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Minutes between automatic rolls. Set to 0 to disable the timer. */
    public int intervalMinutes = 5;
    /** Seconds a player must wait between /getenchant uses. 0 = no cooldown. */
    public int commandCooldownSeconds = 30;
    /** If true, the enchantment is really applied to the held item. If false, it is only announced. */
    public boolean applyToItem = true;
    /** Allow Curse of Binding / Curse of Vanishing and other curses to be rolled. */
    public boolean allowCurses = false;
    /** Only roll this mod's custom enchantments (ignore vanilla and other mods' ones). */
    public boolean onlyCustomEnchants = false;
    /** Allow the timer to roll for players too (otherwise only /getenchant works). */
    public boolean autoRollEnabled = true;

    public static RandomEnchantsConfig load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("random_enchants.json");
        RandomEnchantsConfig config = new RandomEnchantsConfig();
        if (Files.exists(path)) {
            try (Reader reader = Files.newBufferedReader(path)) {
                RandomEnchantsConfig loaded = GSON.fromJson(reader, RandomEnchantsConfig.class);
                if (loaded != null) {
                    config = loaded;
                }
            } catch (Exception e) {
                RandomEnchantsMod.LOGGER.warn("Could not read {}, using defaults", path, e);
            }
        }
        config.intervalMinutes = Math.max(0, config.intervalMinutes);
        config.commandCooldownSeconds = Math.max(0, config.commandCooldownSeconds);
        // Always write back so new options appear in existing files.
        try (Writer writer = Files.newBufferedWriter(path)) {
            GSON.toJson(config, writer);
        } catch (IOException e) {
            RandomEnchantsMod.LOGGER.warn("Could not write {}", path, e);
        }
        return config;
    }
}
