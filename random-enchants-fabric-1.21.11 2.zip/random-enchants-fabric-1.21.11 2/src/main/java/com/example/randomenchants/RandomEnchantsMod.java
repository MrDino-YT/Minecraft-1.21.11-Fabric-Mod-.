package com.example.randomenchants;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class RandomEnchantsMod implements ModInitializer {
    public static final String MOD_ID = "random_enchants";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private RandomEnchantsConfig config;
    private int ticksSinceLastRoll = 0;
    private final Map<UUID, Integer> lastCommandTick = new HashMap<>();

    @Override
    public void onInitialize() {
        config = RandomEnchantsConfig.load();
        EnchantEffects.register();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("getenchant")
                        .executes(context -> {
                            ServerPlayerEntity player = context.getSource().getPlayerOrThrow();
                            MinecraftServer server = context.getSource().getServer();
                            int now = server.getTicks();
                            int cooldownTicks = config.commandCooldownSeconds * 20;
                            Integer last = lastCommandTick.get(player.getUuid());
                            if (cooldownTicks > 0 && last != null && now - last < cooldownTicks) {
                                int remaining = (cooldownTicks - (now - last) + 19) / 20;
                                player.sendMessage(Text.literal("Wait " + remaining + "s before using /getenchant again.")
                                        .formatted(Formatting.RED), false);
                                return 0;
                            }
                            lastCommandTick.put(player.getUuid(), now);
                            EnchantRoller.roll(player, config);
                            return Command.SINGLE_SUCCESS;
                        })));

        ServerTickEvents.END_SERVER_TICK.register(this::onServerTick);
    }

    private void onServerTick(MinecraftServer server) {
        EnchantEffects.tick(server);
        if (!config.autoRollEnabled || config.intervalMinutes <= 0) {
            return;
        }
        ticksSinceLastRoll++;
        if (ticksSinceLastRoll < config.intervalMinutes * 20 * 60) {
            return;
        }
        ticksSinceLastRoll = 0;
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            EnchantRoller.roll(player, config);
        }
    }
}
