package com.example.randomenchants;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Behaviour for the custom enchantments. The enchantments themselves are defined as JSON under
 * data/random_enchants/enchantment/; this class reads their levels and makes them do things.
 */
public final class EnchantEffects {
    private EnchantEffects() {}

    private static RegistryKey<Enchantment> key(String id) {
        return RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(RandomEnchantsMod.MOD_ID, id));
    }

    public static final RegistryKey<Enchantment> LIFESTEAL = key("lifesteal");
    public static final RegistryKey<Enchantment> VENOM = key("venom");
    public static final RegistryKey<Enchantment> FROSTBITE = key("frostbite");
    public static final RegistryKey<Enchantment> EXECUTIONER = key("executioner");
    public static final RegistryKey<Enchantment> SOUL_HARVEST = key("soul_harvest");
    public static final RegistryKey<Enchantment> KILL_RUSH = key("kill_rush");
    public static final RegistryKey<Enchantment> BERSERKER = key("berserker");
    public static final RegistryKey<Enchantment> MOMENTUM = key("momentum");
    public static final RegistryKey<Enchantment> PROSPECTOR = key("prospector");
    public static final RegistryKey<Enchantment> NIGHT_SIGHT = key("night_sight");
    public static final RegistryKey<Enchantment> GILLS = key("gills");
    public static final RegistryKey<Enchantment> REGROWTH = key("regrowth");
    public static final RegistryKey<Enchantment> RETALIATION = key("retaliation");
    public static final RegistryKey<Enchantment> SECOND_WIND = key("second_wind");
    public static final RegistryKey<Enchantment> SWIFTFOOT = key("swiftfoot");
    public static final RegistryKey<Enchantment> EMBER_WARD = key("ember_ward");
    public static final RegistryKey<Enchantment> SPRINGHEEL = key("springheel");

    /** Guards against our own bonus damage triggering our own handlers again. */
    private static boolean busy = false;
    private static final Map<UUID, Integer> secondWindReadyAt = new HashMap<>();
    private static final Set<UUID> pendingSecondWindHeal = new HashSet<>();

    private static int level(World world, RegistryKey<Enchantment> key, ItemStack stack) {
        if (stack.isEmpty()) {
            return 0;
        }
        Registry<Enchantment> registry = world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        Enchantment enchantment = registry.get(key);
        if (enchantment == null) {
            return 0;
        }
        return EnchantmentHelper.getLevel(registry.getEntry(enchantment), stack);
    }

    private static void effect(LivingEntity target, RegistryEntry<StatusEffect> type, int ticks, int amplifier) {
        target.addStatusEffect(new StatusEffectInstance(type, ticks, amplifier));
    }

    /** Quiet effect used for passive armour bonuses (no particles). */
    private static void passive(LivingEntity target, RegistryEntry<StatusEffect> type, int ticks, int amplifier) {
        target.addStatusEffect(new StatusEffectInstance(type, ticks, amplifier, true, false, true));
    }

    public static void register() {
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            // Springheel: boots cancel fall damage.
            if (entity instanceof ServerPlayerEntity player && source.isOf(DamageTypes.FALL)
                    && level(player.getEntityWorld(), SPRINGHEEL, player.getEquippedStack(EquipmentSlot.FEET)) > 0) {
                return false;
            }
            return true;
        });

        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
            if (busy || damageTaken <= 0 || !(entity.getEntityWorld() instanceof ServerWorld world)) {
                return;
            }
            Entity attackerEntity = source.getAttacker();

            // Weapon enchantments: only for the player's own melee hits.
            if (attackerEntity instanceof ServerPlayerEntity player && source.getSource() == player) {
                ItemStack weapon = player.getMainHandStack();

                int lifesteal = level(world, LIFESTEAL, weapon);
                if (lifesteal > 0) {
                    player.heal(damageTaken * 0.08f * lifesteal);
                }
                int venom = level(world, VENOM, weapon);
                if (venom > 0) {
                    effect(entity, StatusEffects.POISON, 60 + 40 * venom, venom >= 3 ? 1 : 0);
                }
                int frostbite = level(world, FROSTBITE, weapon);
                if (frostbite > 0) {
                    effect(entity, StatusEffects.SLOWNESS, 40 + 30 * frostbite, Math.min(frostbite, 3) - 1);
                    effect(entity, StatusEffects.MINING_FATIGUE, 40 + 30 * frostbite, 0);
                }
                int executioner = level(world, EXECUTIONER, weapon);
                if (executioner > 0 && entity.isAlive() && entity.getHealth() <= entity.getMaxHealth() * 0.3f) {
                    busy = true;
                    try {
                        entity.damage(world, world.getDamageSources().playerAttack(player), 2.0f * executioner);
                    } finally {
                        busy = false;
                    }
                }
            }

            // Retaliation: chestplate hurts and weakens whoever hit the wearer.
            if (entity instanceof ServerPlayerEntity victim && attackerEntity instanceof LivingEntity attacker
                    && attacker != victim) {
                int retaliation = level(world, RETALIATION, victim.getEquippedStack(EquipmentSlot.CHEST));
                if (retaliation > 0) {
                    effect(attacker, StatusEffects.WEAKNESS, 60 + 40 * retaliation, 0);
                    busy = true;
                    try {
                        attacker.damage(world, world.getDamageSources().thorns(victim), 1.0f + retaliation);
                    } finally {
                        busy = false;
                    }
                }
            }
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(entity.getEntityWorld() instanceof ServerWorld world)
                    || !(source.getAttacker() instanceof ServerPlayerEntity player)) {
                return;
            }
            ItemStack weapon = player.getMainHandStack();
            int soul = level(world, SOUL_HARVEST, weapon);
            if (soul > 0) {
                ExperienceOrbEntity.spawn(world, entity.getEntityPos(), 2 + 2 * soul);
            }
            int rush = level(world, KILL_RUSH, weapon);
            if (rush > 0) {
                effect(player, StatusEffects.SPEED, 100 + 40 * rush, rush);
                effect(player, StatusEffects.REGENERATION, 60 + 20 * rush, 0);
            }
        });

        // Second Wind: survive a killing blow, then recover.
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, damageAmount) -> {
            if (!(entity instanceof ServerPlayerEntity player) || !(player.getEntityWorld() instanceof ServerWorld world)) {
                return true;
            }
            int lvl = level(world, SECOND_WIND, player.getEquippedStack(EquipmentSlot.CHEST));
            if (lvl <= 0) {
                return true;
            }
            int now = world.getServer().getTicks();
            Integer readyAt = secondWindReadyAt.get(player.getUuid());
            if (readyAt != null && now < readyAt) {
                return true;
            }
            secondWindReadyAt.put(player.getUuid(), now + (5 - lvl) * 2400);
            pendingSecondWindHeal.add(player.getUuid());
            effect(player, StatusEffects.REGENERATION, 200, 2);
            effect(player, StatusEffects.RESISTANCE, 100, 2);
            effect(player, StatusEffects.ABSORPTION, 300, 1);
            player.sendMessage(Text.literal("Second Wind saved you!").formatted(Formatting.AQUA), true);
            return false;
        });

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(world instanceof ServerWorld serverWorld) || !(player instanceof ServerPlayerEntity)) {
                return;
            }
            ItemStack tool = player.getMainHandStack();
            int momentum = level(world, MOMENTUM, tool);
            if (momentum > 0) {
                passive(player, StatusEffects.HASTE, 100, momentum - 1);
            }
            int prospector = level(world, PROSPECTOR, tool);
            if (prospector > 0) {
                String path = Registries.BLOCK.getId(state.getBlock()).getPath();
                if (path.endsWith("_ore") && ThreadLocalRandom.current().nextFloat() < 0.25f * prospector) {
                    ExperienceOrbEntity.spawn(serverWorld, pos.toCenterPos(), 3 + 2 * prospector);
                }
            }
        });
    }

    /** Called every server tick. Handles passive armour/weapon bonuses and Second Wind recovery. */
    public static void tick(MinecraftServer server) {
        if (!pendingSecondWindHeal.isEmpty()) {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                if (pendingSecondWindHeal.remove(player.getUuid()) && player.isAlive()) {
                    player.setHealth(player.getMaxHealth() * 0.4f);
                }
            }
            pendingSecondWindHeal.clear();
        }

        int ticks = server.getTicks();
        if (ticks % 20 != 0) {
            return;
        }
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            if (!player.isAlive() || player.isSpectator()) {
                continue;
            }
            World world = player.getEntityWorld();
            ItemStack head = player.getEquippedStack(EquipmentSlot.HEAD);
            ItemStack chest = player.getEquippedStack(EquipmentSlot.CHEST);
            ItemStack legs = player.getEquippedStack(EquipmentSlot.LEGS);
            ItemStack feet = player.getEquippedStack(EquipmentSlot.FEET);

            if (level(world, NIGHT_SIGHT, head) > 0) {
                passive(player, StatusEffects.NIGHT_VISION, 320, 0);
            }
            if (level(world, GILLS, head) > 0) {
                passive(player, StatusEffects.WATER_BREATHING, 100, 0);
            }
            int swift = level(world, SWIFTFOOT, legs);
            if (swift > 0) {
                passive(player, StatusEffects.SPEED, 60, swift - 1);
            }
            if (level(world, EMBER_WARD, legs) > 0) {
                passive(player, StatusEffects.FIRE_RESISTANCE, 100, 0);
            }
            int spring = level(world, SPRINGHEEL, feet);
            if (spring > 0) {
                passive(player, StatusEffects.JUMP_BOOST, 60, spring - 1);
            }
            int regrowth = level(world, REGROWTH, chest);
            if (regrowth > 0 && ticks % 80 == 0 && player.getHealth() < player.getMaxHealth()) {
                player.heal(regrowth);
            }
            int berserk = level(world, BERSERKER, player.getMainHandStack());
            if (berserk > 0 && player.getHealth() <= player.getMaxHealth() * 0.5f) {
                passive(player, StatusEffects.STRENGTH, 60, berserk - 1);
            }
        }
    }
}
