package com.example.randomenchants;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Picks a random valid enchantment for an item and (optionally) applies it. */
public final class EnchantRoller {
    private static final TagKey<Enchantment> CURSE =
            TagKey.of(RegistryKeys.ENCHANTMENT, Identifier.of("minecraft", "curse"));

    private EnchantRoller() {}

    private static boolean allowedByConfig(Registry<Enchantment> registry, Enchantment enchantment,
                                           RegistryEntry<Enchantment> entry, RandomEnchantsConfig config) {
        if (!config.allowCurses && entry.isIn(CURSE)) {
            return false;
        }
        if (config.onlyCustomEnchants) {
            Identifier id = registry.getId(enchantment);
            return id != null && RandomEnchantsMod.MOD_ID.equals(id.getNamespace());
        }
        return true;
    }

    /** Rolls for one player: enchants the held item if possible, and tells the player what happened. */
    public static void roll(ServerPlayerEntity player, RandomEnchantsConfig config) {
        Registry<Enchantment> registry = player.getEntityWorld().getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        ThreadLocalRandom random = ThreadLocalRandom.current();

        if (!config.applyToItem) {
            // Announcement only (the behaviour of the original resource).
            List<RegistryEntry<Enchantment>> all = new ArrayList<>();
            for (Enchantment enchantment : registry) {
                RegistryEntry<Enchantment> entry = registry.getEntry(enchantment);
                if (allowedByConfig(registry, enchantment, entry, config)) {
                    all.add(entry);
                }
            }
            if (all.isEmpty()) {
                return;
            }
            RegistryEntry<Enchantment> pick = all.get(random.nextInt(all.size()));
            player.sendMessage(Text.literal("You received: ").formatted(Formatting.GOLD)
                    .append(Enchantment.getName(pick, pick.value().getMaxLevel())), false);
            return;
        }

        ItemStack stack = player.getMainHandStack();
        if (stack.isEmpty()) {
            player.sendMessage(Text.literal("Hold an item to enchant it.").formatted(Formatting.GRAY), false);
            return;
        }

        ItemEnchantmentsComponent existing = EnchantmentHelper.getEnchantments(stack);
        List<RegistryEntry<Enchantment>> candidates = new ArrayList<>();
        for (Enchantment enchantment : registry) {
            RegistryEntry<Enchantment> entry = registry.getEntry(enchantment);
            if (!allowedByConfig(registry, enchantment, entry, config) || !enchantment.isAcceptableItem(stack)) {
                continue;
            }
            // Must not clash with anything already on the item (except itself, which we may upgrade).
            boolean clash = false;
            for (RegistryEntry<Enchantment> other : existing.getEnchantments()) {
                if (!other.equals(entry) && !Enchantment.canBeCombined(entry, other)) {
                    clash = true;
                    break;
                }
            }
            if (clash || existing.getLevel(entry) >= enchantment.getMaxLevel()) {
                continue;
            }
            candidates.add(entry);
        }

        if (candidates.isEmpty()) {
            player.sendMessage(Text.literal("Nothing more can be added to this item.").formatted(Formatting.GRAY), false);
            return;
        }

        RegistryEntry<Enchantment> pick = candidates.get(random.nextInt(candidates.size()));
        int current = existing.getLevel(pick);
        int max = pick.value().getMaxLevel();
        // Upgrade an existing enchantment by one level, otherwise roll a fresh level 1..max.
        int level = current > 0 ? current + 1 : 1 + random.nextInt(max);

        EnchantmentHelper.apply(stack, builder -> builder.set(pick, level));

        player.sendMessage(Text.literal("You received: ").formatted(Formatting.GOLD)
                .append(Enchantment.getName(pick, level))
                .append(Text.literal(" on ").formatted(Formatting.GOLD))
                .append(stack.getName()), false);
    }
}
