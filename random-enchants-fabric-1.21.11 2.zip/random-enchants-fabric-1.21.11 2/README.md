# Random Enchants — Fabric 1.21.11

Adds **17 new custom enchantments** and gives the item in your hand a random enchantment.

## New enchantments

They appear in enchanting tables, loot chests and `/getenchant` (Second Wind is treasure: loot/`/getenchant` only), and can be put on books and combined in anvils.

| Enchantment | Goes on | Max | Effect |
|---|---|---|---|
| Lifesteal | weapons | III | Heal 8% of melee damage dealt per level |
| Venom | weapons | III | Poisons the target (Poison II at III) |
| Frostbite | weapons | III | Slows the target and gives Mining Fatigue |
| Executioner | weapons | III | Extra damage to targets under 30% health |
| Soul Harvest | weapons | III | Kills drop bonus XP |
| Kill Rush | weapons | II | Kills give you Speed + Regeneration |
| Berserker | weapons (held) | II | Strength while you're under 50% health |
| Momentum | tools | III | Breaking blocks gives Haste |
| Prospector | tools | III | Chance of bonus XP from ores |
| Night Sight | helmet | I | Permanent night vision |
| Gills | helmet | I | Water breathing |
| Regrowth | chestplate | III | Slowly heals you over time |
| Retaliation | chestplate | III | Attackers take damage and get Weakness |
| Second Wind | chestplate | III | Survive a fatal hit (40% health back), with a cooldown (8 / 6 / 4 min) |
| Swiftfoot | leggings | II | Speed |
| Ember Ward | leggings | I | Fire resistance |
| Springheel | boots | II | Jump Boost and no fall damage |

Definitions are plain JSON in `src/main/resources/data/random_enchants/enchantment/` (cost, weight, max level, items), so they're easy to tweak. The effects live in `EnchantEffects.java`.
Names are stored as plain text, so players without the mod see them correctly too.

## Features

- `/getenchant` enchants the item in your main hand with a random **valid** enchantment.
- Every 5 minutes (configurable) every online player automatically gets one on their held item.
- Only enchantments that fit the item are rolled, never ones that clash with what's already on it
  (e.g. Sharpness + Smite). If the rolled enchantment is already on the item, it is upgraded one level.
- Works with every vanilla enchantment, including ones added by data packs / other mods.
- Server-side only: works in single-player and on a Fabric server, and players don't need it installed.

## Config — `config/random_enchants.json` (created on first launch)

| Option | Default | Meaning |
|---|---|---|
| `intervalMinutes` | `5` | Minutes between automatic rolls. `0` disables the timer. |
| `autoRollEnabled` | `true` | Turn the automatic timer on/off. |
| `commandCooldownSeconds` | `30` | Cooldown for `/getenchant` per player. |
| `applyToItem` | `true` | `false` = only announce a random enchantment, don't change items (original Lua behaviour). |
| `allowCurses` | `false` | Allow Curse of Binding / Vanishing to be rolled. |
| `onlyCustomEnchants` | `false` | `/getenchant` and the timer only roll this mod's 17 enchantments. |

## Requirements

Minecraft 1.21.11 · Java 21 · Fabric Loader 0.18.1+ · Fabric API (0.141.6+1.21.11 or newer for 1.21.11)

## Build

```sh
./gradlew build
```

The mod is `build/libs/random-enchants-1.0.0.jar` (not the `-sources` jar). Put it in `mods/` together with Fabric API.
No local setup? Push this folder to GitHub — the included workflow builds the jar and attaches it to the run.
